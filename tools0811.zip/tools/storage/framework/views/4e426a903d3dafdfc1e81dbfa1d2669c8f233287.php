<header class="bg_blue">
	<nav class="navbar navbar-expand-md">
  		<div class="container-fluid heade_container">
    		<p class="m-0 h4 text-white logo">TEXT LOGO</p>
				<div class="d-none d-md-block">
      				<ul class="navbar-nav m-auto mb-2 mb-lg-0">
				        <li class="nav-item">
				          <a class="nav-link text-white active" aria-current="page" href="#">Home</a>
				        </li>
				        <li class="nav-item">
				          <a class="nav-link text-white" href="#">About</a>
				        </li>
				         <li class="nav-item">
				          <a class="nav-link text-white" href="#">Contact</a>
				        </li>
				        <li class="nav-item dropdown">
				          <a class="nav-link dropdown-toggle text-white" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
				            Pages
				          </a>
				          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
				            <li><a class="dropdown-item" href="#">Action</a></li>
				            <li><a class="dropdown-item" href="#">Another action</a></li>
				            
				            <li><a class="dropdown-item" href="#">Something else here</a></li>
				          </ul>
				        </li>        
     				 </ul>    
				</div>
   				<div class="d-flex justify-content-between align-items-center mobile_mode">
					<div class="checkbox d-flex justify-content-between align-items-center" id="change" >
				  <div class="pe-2">
				  	<div id="modeIconN" style="display:none;"><img src="<?php echo e(asset('public/images/night_mode.svg')); ?>"> </div>
				  	<div id="modeIconD"><img src="<?php echo e(asset('public/images/day_mode.svg')); ?>"></div>
				  </div>
				<div class=" d-flex justify-content-between align-items-center">
				  	<p class="mb-0 text-white me-3" id="changeText">Light Mode</p>
					<label class="switch" checked>
					  <input type="checkbox" onchange="myFunction()" >
					  <span class="slider round"></span>
					</label>
				</div>
				</div>
				<div class="share_icon">
					<!-- AddToAny BEGIN -->
					<div class="a2a_kit a2a_kit_size_32 a2a_default_style">
					<a class="a2a_dd" href="https://www.addtoany.com/share">
						<i class="fa fa-share"></i>
					</a>
				</div>
				<script async src="https://static.addtoany.com/menu/page.js"></script>
				</div>
			</div>
		</div>
	</nav>
</header><?php /**PATH F:\wamp\www\tools\resources\views/include/front_header.blade.php ENDPATH**/ ?>