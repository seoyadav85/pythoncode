<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<script type="text/javascript" src="<?php echo e(asset('public/js/jquery.min.js')); ?>"></script>
<script type="text/javascript">
	setTimeout(function() {
    $('.alert').remove();
}, 10000); 
</script><?php /**PATH F:\wamp\www\survey - Copy\resources\views/include/flash.blade.php ENDPATH**/ ?>