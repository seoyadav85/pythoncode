
<?php $__env->startSection('content'); ?>
        <div class="content-wrapper">
           <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Change Password</h4>
                  <form action="<?php echo e(route('admin.user.doChangePassword')); ?>" name="frm_password" id="frm_password" method="post">
                    <?php echo e(csrf_field()); ?>

                  <div class="row">
                    <div class="col-md-3">
                      <div class="form-group">
                        <input type="password" class="form-control" id="old_password" name="old_password" placeholder="Old Password" value="<?php echo e(old('old_password')); ?>">
                        <span class="text-danger"><?php echo e($errors->first('old_password')); ?></span>
                      </div>
                    </div>
                     <div class="col-md-3">
                      <div class="form-group">
                        <input type="password" class="form-control" id="new_password" name="new_password" placeholder="New Password"  value="<?php echo e(old('new_password')); ?>">
                        <span class="text-danger"><?php echo e($errors->first('new_password')); ?></span>
                      </div>
                    </div>
                     <div class="col-md-3">
                      <div class="form-group">
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Confirm Password"  value="<?php echo e(old('confirm_password')); ?>">
                        <span class="text-danger"><?php echo e($errors->first('confirm_password')); ?></span>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="form-group">
                        <button type="submit" class="btn btn-primary">Change Password</button>
                      </div>
                    </div>
                    <!-- <div class="col-md-2" style="margin-left: 16px">
                      <div class="form-group">
                        <button type="reset" id="btnReset" class="btn btn-success">Reset</button>
                      </div>
                    </div> -->
                  </div>
                </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      
       <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vertexmi/public_html/tools/resources/views/admin/user/change_password.blade.php ENDPATH**/ ?>