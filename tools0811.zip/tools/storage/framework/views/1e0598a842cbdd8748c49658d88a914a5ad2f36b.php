
<?php $__env->startSection('content'); ?>
        <div class="content-wrapper">
           <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Users List</h4>
                  <a href="<?php echo e(route('admin.user.create')); ?>" class="btn btn-primary" style="float:right;">Add User</a>
                  <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>Name</th>
                          <th>Email</th>
                          <th>DOB</th>
                          <th>Gender</th>
                          <th>Postal Code</th>
                          <th>Created</th>
                          <th>Status</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php if($data->isNotEmpty()): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                        
                        <tr>
                          <td><?php echo e($value->name); ?></td>
                          <td><?php echo e($value->email); ?></td>
                          <td><?php echo e(date('d-M-Y',strtotime($value->dob))); ?></td>
                          <td>
                            <?php if($value->gender == 1): ?>
                            Male
                            <?php else: ?>
                            Female
                            <?php endif; ?>
                          </td>
                          <td><?php echo e($value->postal_code); ?></td>
                          <td><?php echo e(date('d-M-Y',strtotime($value->created_at))); ?></td>
                          <td>
                            <?php if($value->status == 1): ?>
                            <span style="color:green">Active</span>
                            <?php else: ?>
                            <span style="color:red">In-Active</span>
                            <?php endif; ?>
                          </td>
                          <td>
                           <!--  <a href="#"><i class="ti-eye" style="font-size:20px;"></i></a> -->
                            <a href="<?php echo e(route('admin.user.edit', $value->id)); ?>"><i class="ti-pencil" style="font-size:20px;margin-left:5px"></i></a>
                             <a href="<?php echo e(route('admin.user.delete',$value->id)); ?>"><i class="ti-trash" style="font-size:20px;margin-left:5px;color: red"></i></a>
                          </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                         <tr>
                          <td colspan="7" style="text-align: center;">No Record Found</td>                          
                        </tr>
                        <?php endif; ?>
                      </tbody>
                    </table>
                    <div class="pagination" style="float:right;">
                      <?php echo e($data->render()); ?> 
                  </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
       <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\wamp\www\survey\resources\views/admin/user/user_list.blade.php ENDPATH**/ ?>