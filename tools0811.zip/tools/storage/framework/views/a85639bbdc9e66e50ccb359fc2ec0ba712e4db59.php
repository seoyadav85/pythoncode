<div class="row">
    <div class="col-md-6">
      <div class="form-group row <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
        <label class="col-sm-3 col-form-label">Name</label>
        <div class="col-sm-9">
           <input type="text" name="name" class="form-control" placeholder="Your Name*" required value="<?php echo e(old('name', isset($data->name) ? $data->name : '')); ?>" >
          <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="form-group row <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
        <label class="col-sm-3 col-form-label">Email</label>
        <div class="col-sm-9">
           <input type="email" name="email" class="form-control" placeholder="Your Email*" required value="<?php echo e(old('email', isset($data->email) ? $data->email : '')); ?>">
           <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
        </div>
      </div>
    </div>
  </div>
  <?php if(Route::currentRouteName() == 'admin.user.add'): ?>
  <div class="row">
    <div class="col-md-6">
      <div class="form-group row">
        <label class="col-sm-3 col-form-label">Passowrd</label>
        <div class="col-sm-9">
           <input type="password" name="password" class="form-control" placeholder="Your password*" required >
           <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="form-group row">
        <label class="col-sm-3 col-form-label">Confirm Password</label>
        <div class="col-sm-9">
           <input type="password" name="confirm_password" class="form-control" placeholder="Your Confirm password*" required >
           <span class="text-danger"><?php echo e($errors->first('confirm_password')); ?></span>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>
  <div class="row">
    <div class="col-md-6">
      <div class="form-group row">
        <label class="col-sm-3 col-form-label">Gender</label>
        <div class="col-sm-9">
          <?php if(Route::currentRouteName() == 'admin.user.add'): ?>
          <select class="form-control" name="gender" >
            <option value="">Please Select Gender</option>
            <option value="1" <?php echo e(old('gender') == 1 ? 'selected' : ''); ?>>Male</option>
            <option value="2" <?php echo e(old('gender') == 2 ? 'selected' : ''); ?>>Female</option>
          </select>
          <?php elseif(Route::currentRouteName() == 'admin.user.edit'): ?>
           <select class="form-control" name="gender" >
            <option value="">Please Select Gender</option>
            <option value="1" <?php echo e($data->gender == 1 ? 'selected' : ''); ?>>Male</option>
            <option value="2" <?php echo e($data->gender == 2 ? 'selected' : ''); ?>>Female</option>
          </select>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="form-group row">
        <label class="col-sm-3 col-form-label">Date of Birth</label>
        <div class="col-sm-9">
          <input type="date" name="dob" class="form-control" value="<?php echo e(old('dob', isset($data->dob) ? $data->dob : '')); ?>" placeholder="dd/mm/yyyy"/>
        </div>
      </div>
    </div>
  </div>
 
 <div class="row">
    <div class="col-md-6">
      <div class="form-group row">
        <label class="col-sm-3 col-form-label">Address</label>
        <div class="col-sm-9">
           <input type="text" class="form-control" name="address" rows="3" placeholder="Address" value="<?php echo e(old('address', isset($data->address) ? $data->address : '')); ?>" >
           <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="form-group row">
        <label class="col-sm-3 col-form-label">Postal Code</label>
        <div class="col-sm-9">
           <input type="text" name="postal_code" class="form-control" placeholder="Postal Code" value="<?php echo e(old('postal_code', isset($data->postal_code) ? $data->postal_code : '')); ?>" >
           <span class="text-danger"><?php echo e($errors->first('postal_code')); ?></span>
        </div>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-md-6">
      <div class="form-group row">
        <label class="col-sm-3 col-form-label">Status</label>
        <div class="col-sm-9">
          <?php if(Route::currentRouteName() == 'admin.user.add'): ?>
          <select class="form-control" name="status" >
            <option value="">Please Select Status</option>
            <option value="1" <?php echo e(old('status') == 1 ? 'selected' : ''); ?>>Male</option>
            <option value="2" <?php echo e(old('status') == 2 ? 'selected' : ''); ?>>Female</option>
          </select>
          <?php elseif(Route::currentRouteName() == 'admin.user.edit'): ?>
           <select class="form-control" name="status" >
            <option value="">Please Select Status</option>
            <option value="1" <?php echo e($data->status == 1 ? 'selected' : ''); ?>>Male</option>
            <option value="2" <?php echo e($data->status == 2 ? 'selected' : ''); ?>>Female</option>
          </select>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
  <?php /**PATH F:\wamp\www\survey\resources\views/admin/user/form.blade.php ENDPATH**/ ?>