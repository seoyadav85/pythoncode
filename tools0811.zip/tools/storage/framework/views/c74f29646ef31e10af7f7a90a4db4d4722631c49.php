

<?php $__env->startSection('content'); ?>

<main class="container-fluid">
   <section class="widget w-100">
      <header class="widget-header">
         <h1 class="fs-4">Find & Replace Tool</h1>
      </header>
      <div class="widget-body">
         <div class="d-flex justify-content-between align-items-center btn_top">           
         	<div class="left_Sec">         		
         		<div class="dropdowns d-flex">
 					<div class="dropdown">
					  <button class="btn btn-outline border_blue dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
					    File
					  </button>
					  <ul class="dropdown-menu">
					    <li> <a href="#" id="file_new"><i class="fa fa-file"></i> New</a> </li>
					    <li> <a href="#" id="file_new"><i class="fa fa-folder-open-o"></i> Open</a> </li>
					    <li> <a href="#" id="file_new"><i class="fa fa-save"></i> Save as</a> </li>
					    <li> <a href="#" id="file_new"><i class="fa fa-print "></i> Print</a> </li>
					  </ul>
					</div>
					<div class="dropdown ms-2">
					  <button class="btn btn-outline border_blue dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
					    Edit
					  </button>
					  <ul class="dropdown-menu">
					     <li> <a href="#" id="file_new"><i class="fa fa-file"></i> Undo</a> </li>
					    <li> <a href="#" id="file_new"><i class="fa fa-folder-open-o"></i> Redo</a> </li>
					    <li> <a href="#" id="file_new"><i class="fa fa-save"></i> Copy</a> </li>
					    <li> <a href="#" id="file_new"><i class="fa fa-print "></i> Delete</a> </li>
					    <li> <a href="#" id="file_new"><i class="fa fa-print "></i> Sellect All</a> </li>
					  </ul>
					</div>
         		</div>
         	</div>
			<div class="right_Sec d-flex align-items-center">
				<div class="me-3">		
					<div class="form-check form-switch">
					  <input class="form-check-input" type="checkbox" role="switch" id="caseSen">
					  <label class="form-check-label" for="caseSen">Match case</label>
					</div>
				</div>
                <div class="me-3">      
                    <div class="form-check form-switch">
                      <input class="form-check-input" type="checkbox" role="switch" id="wholeWords">
                      <label class="form-check-label" for="caseSen">Whole word</label>
                    </div>
                </div>
			<div>
			
		</div>
	</div>
</div>
</section>
<section>
    <div class="w-100 clear margin-y">
                <div class="w-50 left spacer-r xs-100 main">
                    <label for="find">Find this</label> 
                    <textarea id="find" class="margin-0" spellcheck="false" style="font-family: Arial; font-size: 16px;"></textarea>
                </div>
                <div class="w-50 left spacer-l xs-100 main xs-spacer-n">
                    <label for="replace">Replace it with</label> 
                    <textarea id="replace" class="margin-0" spellcheck="false" style="font-family: Arial; font-size: 16px;"></textarea>
                </div>
            </div>
</section>
   <div class="textarea_section mt-4"  >
	   <label for="input_output">Input/output</label> 
	   <textarea id="input_output" spellcheck="false" rows="10" class="w-100"></textarea>
	   <div class="clipboard">
	   	<span class="tooltipped tooltipped-n" aria-label="Click to copy" role="button"><i class="i-copy"></i>
	   	</span>
	   </div>
	   <div class="btn_sec mt-2">
	   <div class="d-flex justify-content-end mb-2">

	   	<button id="convertBtn" type="button" class="btn btn-primary xs-left me-2">Convert</button> 
	   	<button id="clearAll" type="button" class="btn btn-secondary xs-right">Clear</button>
	   </div>
	</div>
	</div>
	<div class="row">
		<div class="widget col-md-8 box-content">
         <header class="widget-header">
            <h2>About</h2>
         </header>
         <hr>
         <p>Use this tool to sort an unordered list in alphabetical or natural order. You can sort in ascending or descending order. You can also sort based on character length/width.</p>
         <header class="widget-header">
            <h2>Sorting Method</h2>
         </header>
         <hr>
         <p>There are three different ways of sorting text lines using this tool.</p>
         <ul>
            <li>
               <p><strong>Alphabetical order</strong> - Alphabetical sorting is the traditional way a computer sort text. Each character is compared in order and the string whose first letter comes earlier in the alphabet (A-Z) comes first. This also applies to numbers (0-9).</p>
            </li>
            <li>
               <p><strong>Natural order</strong> - Natural sort is considered a more human-friendly implementation of machine alphabetical sorting. Non-single-digit numbers like "10", "11", "12", and above are considered as a single entity and ordered by the value of the number. This is what you should use if you're working with numbered lists.</p>
            </li>
            <li>
               <p><strong>By Character Length</strong> - You can sort a list based on the length/width of the text. String with shorter character length comes first in the list and the longest comes last.</p>
            </li>
         </ul>
         <header class="widget-header">
            <h2>Basic Examples</h2>
         </header>
         <hr>
         <div class="content_edit">
         <strong>Alphabetical sort</strong> - In the given example below, "A10" comes first before "A2" because "1" is bigger than "1".
         <pre>A1
A10
A2</pre>
</div>
<div class="content_edit">
 <strong>Natural sort</strong>
 <pre>A1
	A2
	A10</pre>
	</div>
<div class="content_edit">
 <strong>Character Length</strong>
 <pre>A
	AA
	AAA
	</pre>
	</div>
	 <header class="widget-header">
	    <h2>Reverse</h2>
	 </header>
	 <hr>
	 <p>Using this option reverses the order of the text.</p>
	 Example: Reversed after sorting by character length.
	 <pre>AAA
	AA
	A</pre>
         <header class="widget-header">
            <h2>How to Sort a List in Descending Order</h2>
         </header>
         <hr>
         <p>Texts are sorted in ascending order by default. If you want to sort a list in descending order (9-0 and Z-A), you can use the reverse option after sorting it alphabetically or naturally.</p>
         <p><b>Update:</b> You can now sort in descending order directly by using Z-A option.</p>
         <header class="widget-header">
            <h3>How to Sort a List Randomly</h3>
         </header>
         <hr>
         <p>You can sort text in no particular order by using <strong>Shuffle</strong>. It randomizes the arrangement of the list.</p>
      </div>
	<div class="sidebar-box col-md-4"><div class="card p-2">
    <h3 class="sidebar-heading">Popular Articles</h3>
    <div class="block-21 mb-4 d-flex">
        <a class="blog-img mr-4"><img src="img/blog.png"> </a>
        <div class="text">
            <h3 class="heading"><a href="#">Even the all-powerful Pointing has no control</a></h3>
            <div class="meta">
                <div>
                    <a href="#"><span class="icon-calendar"></span> June 28, 2019</a>
                </div>
                <div>
                    <a href="#"><span class="icon-person"></span> Dave Lewis</a>
                </div>
                <div>
                    <a href="#"><span class="icon-chat"></span> 19</a>
                </div>
            </div>
        </div>
    </div>
    <div class="block-21 mb-4 d-flex">
 <a class="blog-img mr-4"><img src="img/blog.png"> </a>
        <div class="text">
            <h3 class="heading"><a href="#">Even the all-powerful Pointing has no control</a></h3>
            <div class="meta">
                <div>
                    <a href="#"><span class="icon-calendar"></span> June 28, 2019</a>
                </div>
                <div>
                    <a href="#"><span class="icon-person"></span> Dave Lewis</a>
                </div>
                <div>
                    <a href="#"><span class="icon-chat"></span> 19</a>
                </div>
            </div>
        </div>
    </div>
    <div class="block-21 mb-4 d-flex">
        <a class="blog-img mr-4"><img src="img/blog.png"> </a>
        <div class="text">
            <h3 class="heading"><a href="#">Even the all-powerful Pointing has no control</a></h3>
            <div class="meta">
                <div>
                    <a href="#"><span class="icon-calendar"></span> June 28, 2019</a>
                </div>
                <div>
                    <a href="#"><span class="icon-person"></span> Dave Lewis</a>
                </div>
                <div>
                    <a href="#"><span class="icon-chat"></span> 19</a>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
  
</main>

<script type="text/javascript" src="<?php echo e(asset('/public/js/jquery.min.js')); ?>"></script>
<script>
    $('#convertBtn').click(function()
    {
        var txtVal = $('#input_output').val();
        var findVal = $('#find').val();
        var replaceVal = $('#replace').val();
        if(txtVal != '')
        {
            if(document.getElementById('caseSen').checked && document.getElementById('wholeWords').checked)
            {
                var convertVal = txtVal.replace(new RegExp("\\b"+findVal+"\\b","g"), replaceVal);
                $('#input_output').val(convertVal);
            }
            else if(document.getElementById('caseSen').checked && !document.getElementById('wholeWords').checked)
            {
                var convertVal = txtVal.replaceAllWithCase(findVal, replaceVal);
                $('#input_output').val(convertVal);
            }
            else if(!document.getElementById('caseSen').checked && document.getElementById('wholeWords').checked)
            {               
                var convertVal = txtVal.replace(new RegExp("\\b"+findVal+"\\b","ig"), replaceVal);
                $('#input_output').val(convertVal);
            }
            else if(!document.getElementById('caseSen').checked && !document.getElementById('wholeWords').checked)
            {
                var convertVal = txtVal.replaceAll(findVal, replaceVal);
                $('#input_output').val(convertVal);
            }
            
        }            
    });

    String.prototype.replaceAll = function(strReplace, strWith) {
        var esc = strReplace.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
        var reg = new RegExp(esc, 'ig');
        return this.replace(reg, strWith);
    };

    String.prototype.replaceAllWithCase = function(strReplace, strWith) {
        var esc = strReplace.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
        var reg = new RegExp(esc, 'g');
        return this.replace(reg, strWith);
    };
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\wamp\www\tools\resources\views/find_replace.blade.php ENDPATH**/ ?>