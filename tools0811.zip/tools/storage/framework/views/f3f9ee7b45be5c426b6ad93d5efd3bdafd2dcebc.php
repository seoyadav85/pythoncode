
<?php $__env->startSection('content'); ?>
        <div class="content-wrapper">
           <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Categories List</h4>
                  <a href="<?php echo e(route('admin.category.create')); ?>" class="btn btn-primary" style="float:right;">Add Category</a>
                  <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>Title</th>
                          <th>Image</th>
                          <th>Created</th>
                          <th>Status</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php if($data->isNotEmpty()): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                        
                        <tr>
                          <td><?php echo e($value->title); ?></td>
                          <td>
                            <img src="<?php echo e(URL('/public/uploads/category/').'/'.$value->image); ?>" width="150" height="150">
                          </td>
                          <td><?php echo e(date('d-M-Y',strtotime($value->created_at))); ?></td>
                          <td>
                            <?php if($value->status == 1): ?>
                            <span style="color:green">Active</span>
                            <?php else: ?>
                            <span style="color:red">In-Active</span>
                            <?php endif; ?>
                          </td>
                          <td>
                           <!--  <a href="#"><i class="ti-eye" style="font-size:20px;"></i></a> -->
                            <a href="<?php echo e(route('admin.category.edit', $value->id)); ?>"><i class="ti-pencil" style="font-size:20px;margin-left:5px"></i></a>
                             <a href="<?php echo e(route('admin.category.delete',$value->id)); ?>"><i class="ti-trash" style="font-size:20px;margin-left:5px;color: red"></i></a>
                          </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                         <tr>
                          <td colspan="7" style="text-align: center;">No Record Found</td>                          
                        </tr>
                        <?php endif; ?>
                      </tbody>
                    </table>
                    <div class="pagination" style="float:right;">
                      <?php echo e($data->render()); ?> 
                  </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
       <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\wamp\www\survey\resources\views/admin/category/index.blade.php ENDPATH**/ ?>