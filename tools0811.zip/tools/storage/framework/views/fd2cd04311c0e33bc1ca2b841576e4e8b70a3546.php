<div class="row">
    <div class="col-md-6">
      <div class="form-group row <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
        <label class="col-sm-3 col-form-label">Title</label>
        <div class="col-sm-9">
           <input type="text" name="title" class="form-control" placeholder="Category Title*" required value="<?php echo e(old('title', isset($data->title) ? $data->title : '')); ?>" >
          <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="form-group row <?php echo e($errors->has('image') ? 'has-error' : ''); ?>">
        <label class="col-sm-3 col-form-label">Category Image</label>
        <div class="col-sm-9">
           <input type="file" name="image" <?php echo e(!isset($data->image) ? 'required' : ''); ?> class="form-control">
           <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
        </div>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-6">
      <div class="form-group row">
        <label class="col-sm-3 col-form-label">Status</label>
        <div class="col-sm-9">
          <?php if(Route::currentRouteName() == 'admin.category.create'): ?>
          <select class="form-control" name="status" >
            <option value="">Please Select Status</option>
            <option value="1" <?php echo e(old('status') == 1 ? 'selected' : ''); ?>>Active</option>
            <option value="0" <?php echo e(old('status') == 0 ? 'selected' : ''); ?>>Inactive</option>
          </select>
          <?php elseif(Route::currentRouteName() == 'admin.category.edit'): ?>
           <select class="form-control" name="status" >
            <option value="">Please Select Status</option>
            <option value="1" <?php echo e($data->status == 1 ? 'selected' : ''); ?>>Active</option>
            <option value="0" <?php echo e($data->status == 0 ? 'selected' : ''); ?>>Inactive</option>
          </select>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
  <?php if(Route::currentRouteName() == 'admin.category.edit'): ?>
  <div class="row">
    <div class="col-md-6">
      <div class="form-group row">
        <label class="col-sm-3 col-form-label">Category Image Preview</label>
        <div class="col-sm-9">
           <?php if(!empty($data->image)): ?>
           <img src="<?php echo e(url('/public/uploads/category/'.$data->image)); ?>" width="250px" height="250px">
           <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?><?php /**PATH F:\wamp\www\survey\resources\views/admin/category/form.blade.php ENDPATH**/ ?>