<footer class="clear font-14 py-3"><div class="container-fluid d-flex justify-content-between align-items-center">
	<div class="left"><p class="mb-0">© <span id="year">2022</span> Text Tools. All Rights Reserved.</p></div><div class="right">
		<ul class="d-flex mb-0 justify-content-between ps-0"><li><a href="#">Contact Us</a></li><li><a href="#">Sitemap</a></li>
			<li><a href="#">Blog</a></li><li><a href="#">Privacy Policy</a></li>
		</ul>
	</div>
</div>
</footer>
<?php /**PATH F:\wamp\www\tools\resources\views/include/front_footer.blade.php ENDPATH**/ ?>