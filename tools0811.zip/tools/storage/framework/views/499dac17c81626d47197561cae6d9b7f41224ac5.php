<!DOCTYPE html>
<html>
<head>
	<title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

  
  <link rel="stylesheet" href="<?php echo e(asset('public/css/front/bootstrap.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('public/css/front/main.css')); ?>">

</head>
<body>
	<?php echo $__env->make('include.front_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	 <?php echo $__env->yieldContent('content'); ?>
	<?php echo $__env->make('include.front_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <script src="<?php echo e(asset('public/js/jquery.min.js')); ?>"></script>  
  <script src="<?php echo e(asset('public/js/front/bootstrap.bundle.min.js')); ?>"></script>

  <script>

 jQuery( "#change" ).on("click", function() {
            if( jQuery( "#outer_sec" ).hasClass( "dark" )) {
                jQuery( "#outer_sec" ).removeClass( "dark" );
                jQuery( ".change" ).text( "OFF" );
            } else {
                jQuery( "#outer_sec" ).addClass( "dark" );
                jQuery( ".change" ).text( "ON" );
            }
        });
</script>
</div>




<script>
function myFunction() {
   var element = document.body;
   element.classList.toggle("dark-mode");
    var x = document.getElementById("changeText");
    var getclass = document.getElementById("modeIcon");
  if (x.innerHTML === "Dark Mode") {
    x.innerHTML = "Light Mode";

   
  } else {
    x.innerHTML = "Dark Mode"; 
  }
}
</script>
</body>
</html><?php /**PATH F:\wamp\www\tools\resources\views/layouts/front.blade.php ENDPATH**/ ?>