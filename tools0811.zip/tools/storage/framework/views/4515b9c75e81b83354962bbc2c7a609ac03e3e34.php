
<?php $__env->startSection('content'); ?>
        <div class="content-wrapper">
           <div class="row">
            <div class="col-12 grid-margin">
              <div class="card">
                <div style="float: right;">
                  <a style="float: right;margin-right: 5px;margin-top:5px" href="<?php echo e(route('admin.tools.index')); ?>" class="btn btn-info"><i class="ti-back-left"></i></a>  
                </div>                
                <div class="card-body">                  
                  <h4 class="card-title">Update Tool</h4>                  
                  <form class="form-sample" action="<?php echo e(route('admin.tools.update')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                    <?php echo $__env->make('admin.tools.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                   
                   
                    <div class="row">
                      <button type="submit" class="btn btn-primary mb-2">Submit</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
          <script type="text/javascript">
            $(document).ready(function() {
               
              var editor1=CKEDITOR.replace('editor');
              editor1.config.allowedContent = true;
            });
        </script>
       <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vertexmi/public_html/tools/resources/views/admin/tools/edit.blade.php ENDPATH**/ ?>