<?php $__env->startSection('content'); ?>
<section class="bg_gray py-5 empowering">
    <div class="container-fluid">
        <div class="content pb-2">
            <h4 class="fs-1 fw-bolder pt-2 lh-base">Empowering <span class="text_yellow">95+</span> <br>Free Online Tools</h4>
            <p>A collection of the best web-based text processing tools and utilities that will help you automate the recurring tasks of editing and formatting text in spreadsheets, text documents, and HTML files. Using these text manipulation tools can save you many hours of typing and will increase your productivity.</p>
        <section class="container-fluid search_filter py-3">
    <div class="row">
   <div class="col-sm-8">
      <div class="search-box">
         <div class="input-icon input-icon-lg">
            <i class="fa fa-search"></i> 
            <input id="live-search" class="input-lg w-100 text-light border_blue ps-4" type="search" placeholder="Search...">
         </div>
      </div>
   </div>
   <div class="col-sm-4 mt-2 mt-sm-0">
      <select id="categories" class="input-lg w-100 text-light border_blue ps-3">
         <option selected="">All Tools</option>
         <option>Basic Tools</option>
         <option>Text Manipulation</option>
         <option>Text Cleaner</option>
         <option>Text Formatting</option>
         <option>Unicode Text</option>
         <option>Encode &amp; Decode</option>
         <option>Random Generators</option>
         <option>Web Scraping</option>
         <option>More Tools</option>
      </select>
   </div>
 </div>
</section>
        </div>
    </div>
</section>
    <section class="container-fluid py-md-5 listing">
        <div class="heading pb-5 mt-3">
            <h4 class="fs-2 fw-bold text-center text_blue ">BASIC TOOLS</h4>
            <span class="line d-block"></span>
        </div>
        <div class="row">
        <div class="col-lg-4 col-sm-6 mb-4">
            <a href="<?php echo e(route('sort_text')); ?>" class="anchor-div">
                <div class="card text-center h-100 ">
                  <div class="card-body d-flex align-items-center py-md-4">
                    <div class="card_img">
                        <img class="normal" src="<?php echo e(asset('public/images/img1.png')); ?>">
                        <img class="hover" src="<?php echo e(asset('public/images/img1h.png')); ?>">
                    </div>  
                    <div class="card_content">
                    <h5 class="card-title pt-4 pb-2">Sort Text</h5>
                    <p class="card-text">Sort a list in alphabetical, natural, reverse, or random order.</p>
                  </div></div>
                </div>
            </a>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <a href="<?php echo e(route('convert_case')); ?>" class="anchor-div">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img  class="normal"src="<?php echo e(asset('public/images/addcomms.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/addcommsh.png')); ?>">
                </div>
                <div class="card_content">
                <h5 class="card-title pt-4 pb-2">Convert Case</h5>
                <p class="card-text">Change the letter case to uppercase, lowercase, title case, sentence case, or capitalize.</p>
              </div></div>
            </div>
            </a>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <a href="<?php echo e(route('find_replace')); ?>" class="anchor-div">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img  class="normal"src="<?php echo e(asset('public/images/find.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/findh.png')); ?>">
                </div>
                <div class="card_content">
                <h5 class="card-title pt-4 pb-2">Find & Replace</h5>
                <p class="card-text">Find all the instances the text appears in a text and replace it with another word.</p>
            </div>
              </div>
            </div>
            </a>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <a href="<?php echo e(route('reverse_list')); ?>" class="anchor-div">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img  class="normal"src="<?php echo e(asset('public/images/reverse.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/reverseh.png')); ?>">
                </div>
                <div class="card_content">
                <h5 class="card-title pt-4 pb-2">Reverse List</h5>
                <p class="card-text">Flip a list vertically to transform a list in reverse order.</p>
              </div>
            </div>
            </div>
            </a>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img  class="normal"src="<?php echo e(asset('public/images/difference.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/differenceh.png')); ?>">
                </div>
                <div class="card_content">
                <h5 class="card-title pt-4 pb-2">Difference Checker</h5>
                <p class="card-text">Compare text files and find the difference between the two.</p>
              </div></div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img  class="normal"src="<?php echo e(asset('public/images/word.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/wordh.png')); ?>">
                </div>
                <div class="card_content">
                <h5 class="card-title pt-4 pb-2">Word Count</h5>
                <p class="card-text">Find out how many words, sentences, paragraphs, and characters you have written.</p>
              </div>
            </div>
            </div>
        </div>
        </div>

        <div class="heading pb-5 pt-4">
            <h4 class="fs-2 fw-bold text-center text_blue ">TEXT MANIPULATION</h4>
            <span class="line d-block"></span>
        </div>
        <div class="row">
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100 ">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img class="normal" src="<?php echo e(asset('public/images/addlinenumber.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/addlinenumberh.png')); ?>">
                </div>  
                <div class="card_content">
                <h5 class="card-title pt-4 pb-2">Add Prefix & Suffix</h5>
                <p class="card-text">Place any character/s at the beginning and/or at the end of each line.</p>
              </div>
            </div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img  class="normal"src="<?php echo e(asset('public/images/addline.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/addlineh.png')); ?>">
                </div>
                <div class="card_content">
                <h5 class="card-title pt-4 pb-2">Add Line Breaks</h5>
                <p class="card-text">Split a block of text into multiple lines by adding line breaks/new lines.</p>
              </div></div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img  class="normal"src="<?php echo e(asset('public/images/remove.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/removeh.png')); ?>">
                </div>
                <div class="card_content">
                <h5 class="card-title pt-4 pb-2">Remove Line Breaks</h5>
                <p class="card-text">Sort a list in alphabetical, natural, reverse, or random order.</p>
              </div>
            </div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img  class="normal"src="<?php echo e(asset('public/images/concatenate.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/concatenateh.png')); ?>">
                </div>
                <div class="card_content">
                <h5 class="card-title pt-4 pb-2">Concatenate Text</h5>
                <p class="card-text">Combine/merge two documents by concatenating texts line by line.</p>
              </div>
            </div>
            </div>
        </div>
        
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img  class="normal"src="<?php echo e(asset('public/images/split.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/splith.png')); ?>">
                </div>
                <div class="card_content">
                <h5 class="card-title pt-4 pb-2">Split Text</h5>
                <p class="card-text">Specify the delimiter and split a text into individual columns, or by new line.</p>
              </div>
            </div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img  class="normal"src="<?php echo e(asset('public/images/extract.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/extracth.png')); ?>">
                </div>
                <div class="card_content">
                <h5 class="card-title pt-4 pb-2">Extract Column</h5>
                <p class="card-text">Split a delimited text and grab a specific column.</p>
              </div></div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img  class="normal"src="<?php echo e(asset('public/images/swap.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/swaph.png')); ?>">
                </div>
                <div class="card_content">
                <h5 class="card-title pt-4 pb-2">Swap Columns</h5>
                <p class="card-text">Swap two columns from a delimited text.</p>
              </div></div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img  class="normal"src="<?php echo e(asset('public/images/reverseword.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/reversewordh.png')); ?>">
                </div>
                <div class="card_content">
                <h5 class="card-title pt-4 pb-2">Reverse Words</h5>
                <p class="card-text">Reverse the order of words in a text.</p>
              </div></div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img  class="normal"src="<?php echo e(asset('public/images/reverseletter.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/reverseletterh.png')); ?>">
                </div>
                <div class="card_content">
                <h5 class="card-title pt-4 pb-2">Reverse Letters</h5>
                <p class="card-text">Reverse the order of letters in a text.</p>
              </div></div>
            </div>
        </div>
        </div>

        <div class="heading pb-5 pt-4">
            <h4 class="fs-2 fw-bold text-center text_blue ">TEXT CLEANER</h4>
            <span class="line d-block"></span>
        </div>
        <div class="row">
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100 ">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img class="normal" src="<?php echo e(asset('public/images/removeextra.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/removeextrah.png')); ?>">
                </div>  
                <div class="card_content">
                <h5 class="card-title pt-4 pb-2">Remove Extra Spaces</h5>
                <p class="card-text">Trim leading and trailing spaces and convert multiple spaces into a single space.</p>
              </div></div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img  class="normal"src="<?php echo e(asset('public/images/removedup.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/removeduph.png')); ?>">
                </div>
                <div class="card_content">
                <h5 class="card-title pt-4 pb-2">Remove Duplicate Lines</h5>
                <p class="card-text">Find identical lines in a document an
d delete duplicates to clean up your text.</p>
              </div></div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img  class="normal"src="<?php echo e(asset('public/images/removeempty.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/removeemptyh.png')); ?>">
                </div>
                <div class="card_content">
                <h5 class="card-title pt-4 pb-2">Remove Empty Lines</h5>
                <p class="card-text">Get rid of all the lines in a text that only consist of spaces or tabs.</p>
              </div></div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img  class="normal"src="<?php echo e(asset('public/images/removeletter.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/removeletterh.png')); ?>">
                </div>
                <div class="card_content">
                <h5 class="card-title pt-4 pb-2">Remove Letter Accents</h5>
                <p class="card-text">Remove accents or diacritics to transform accented letters into Latin characters.</p>
              </div></div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img  class="normal"src="<?php echo e(asset('public/images/removeunw.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/removeunwh.png')); ?>">
                </div>
                <div class="card_content">
                <h5 class="card-title pt-4 pb-2">Remove Unwanted Characters</h5>
                <p class="card-text">Remove specific unwanted characters, or delete all non-alphanumeric from the text.</p></div>
              </div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img  class="normal"src="<?php echo e(asset('public/images/img1.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/img1h.png')); ?>">
                </div>
                <div class="card_content">
                <h5 class="card-title pt-4 pb-2">Remove Lines Containing</h5>
                <p class="card-text">Remove lines containing or not containing a specific word, phrase, or string in a text.</p></div>
              </div>
            </div>
        </div>
        </div>



        <div class="heading pb-5 pt-4">
            <h4 class="fs-2 fw-bold text-center text_blue ">TEXT FORMATTING</h4>
            <span class="line d-block"></span>
        </div>
        <div class="row">
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100 ">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img class="normal" src="<?php echo e(asset('public/images/reverse.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/reverseh.png')); ?>">
                </div>  <div class="card_content">
                <h5 class="card-title pt-4 pb-2">Add Line Numbers</h5>
                <p class="card-text">Add sequential numbers, letters, or roman numerals at the beginning of each line.</p>
              </div></div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img  class="normal"src="<?php echo e(asset('public/images/addcomms.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/addcommsh.png')); ?>">
                </div><div class="card_content">
                <h5 class="card-title pt-4 pb-2">Add Commas to Numbers</h5>
                <p class="card-text">Add commas or periods to unformatted numbers in a text.</p>
              </div></div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img  class="normal"src="<?php echo e(asset('public/images/addcomms.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/addcommsh.png')); ?>">
                </div><div class="card_content">
                <h5 class="card-title pt-4 pb-2">Replace Smart/Straight Quotes</h5>
                <p class="card-text">Replace curly/smart quotes with regular straight quotes and vice versa.</p>
              </div></div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img class="normal" src="<?php echo e(asset('public/images/reverse.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/reverseh.png')); ?>">
                </div><div class="card_content">
                <h5 class="card-title pt-4 pb-2">Tabs to Spaces</h5>
                <p class="card-text">Take up less white space by converting tabs to spaces.</p>
              </div></div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img  class="normal"src="<?php echo e(asset('public/images/addcomms.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/addcommsh.png')); ?>">
                </div><div class="card_content">
                <h5 class="card-title pt-4 pb-2">Spaces to Tabs</h5>
                <p class="card-text">Convert spaces to tabs for formatting purposes.</p>
              </div></div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img  class="normal"src="<?php echo e(asset('public/images/addcomms.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/addcommsh.png')); ?>">
                </div><div class="card_content">
                <h5 class="card-title pt-4 pb-2">Pad Text</h5>
                <p class="card-text">Pad text to the left or right with spaces or any character.</p>
              </div></div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img class="normal" src="<?php echo e(asset('public/images/reverse.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/reverseh.png')); ?>">
                </div><div class="card_content">
                <h5 class="card-title pt-4 pb-2">Word Wrap</h5>
                <p class="card-text">Wrap text based on specified character length per line.</p>
              </div></div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img  class="normal"src="<?php echo e(asset('public/images/addcomms.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/addcommsh.png')); ?>">
                </div>
                <div class="card_content">
                <h5 class="card-title pt-4 pb-2">Justify Text</h5>
                <p class="card-text">Wraps words to a specified length and justifies the text in each line.</p>
              </div></div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img  class="normal"src="<?php echo e(asset('public/images/addcomms.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/addcommsh.png')); ?>">
                </div>
                <div class="card_content">
                <h5 class="card-title pt-4 pb-2">Center Text</h5>
                <p class="card-text">Center text horizontally by equally padding the left and the right side with spaces.</p></div>
              </div>
            </div>
        </div>
        </div>

        <div class="heading pb-5 pt-4">
            <h4 class="fs-2 fw-bold text-center text_blue ">UNICODE TEXT</h4>
            <span class="line d-block"></span>
        </div>
        <div class="row">
        
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img class="normal" src="<?php echo e(asset('public/images/reverse.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/reverseh.png')); ?>">
                </div>
                <div class="card_content">
                <h5 class="card-title pt-4 pb-2">Add Line Numbers</h5>
                <p class="card-text">Add sequential numbers, letters, or roman numerals at the beginning of each line.</p>
              </div></div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img  class="normal"src="<?php echo e(asset('public/images/addcomms.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/addcommsh.png')); ?>">
                </div>
                <div class="card_content">
                <h5 class="card-title pt-4 pb-2">Add Commas to Numbers</h5>
                <p class="card-text">Add commas or periods to unformatted numbers in a text.</p>
              </div></div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img  class="normal"src="<?php echo e(asset('public/images/addcomms.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/addcommsh.png')); ?>">
                </div><div class="card_content">
                <h5 class="card-title pt-4 pb-2">Replace Smart/Straight Quotes</h5>
                <p class="card-text">Replace curly/smart quotes with regular straight quotes and vice versa.</p>
              </div></div>
            </div>
        </div>


        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img class="normal" src="<?php echo e(asset('public/images/reverse.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/reverseh.png')); ?>">
                </div>
                <div class="card_content">
                <h5 class="card-title pt-4 pb-2">Tabs to Spaces</h5>
                <p class="card-text">Take up less white space by converting tabs to spaces.</p>
              </div></div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img  class="normal"src="<?php echo e(asset('public/images/addcomms.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/addcommsh.png')); ?>">
                </div>
                <div class="card_content">
                <h5 class="card-title pt-4 pb-2">Spaces to Tabs</h5>
                <p class="card-text">Convert spaces to tabs for formatting purposes.</p>
              </div></div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-6 mb-4">
            <div class="card text-center h-100">
              <div class="card-body d-flex align-items-center py-md-4">
                <div class="card_img">
                    <img  class="normal"src="<?php echo e(asset('public/images/addcomms.png')); ?>">
                    <img class="hover" src="<?php echo e(asset('public/images/addcommsh.png')); ?>">
                </div><div class="card_content">
                <h5 class="card-title pt-4 pb-2">Pad Text</h5>
                <p class="card-text">Pad text to the left or right with spaces or any character.</p>
              </div></div>
            </div>
        </div>



        </div>
    </section>


    <div class="jumbotron footer_top py-5"><div class="container-fluid padding-y"><h4 class="font-18"><b>Welcome to TextTools.org</b></h4><p class="mb-0">A collection of the best web-based text processing tools and utilities that will help you automate the recurring tasks of editing and formatting text in spreadsheets, text documents, and HTML files. Using these text manipulation tools can save you many hours of typing and will increase your productivity. You can find more than 50 useful power tools here with different functions, from sorting data, converting letter cases, cleaning texts, and removing unwanted characters, to advanced replacement operations. Say goodbye to tedious and repetitive office tasks. Feel free to bookmark the <strong><a href="/">Text Tools</a></strong> homepage to make it easier to find any text tools anytime you need them. All web tools here are free to use without a daily limit, and no sign-up is required!</p></div></div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\wamp\www\tools\resources\views/welcome.blade.php ENDPATH**/ ?>