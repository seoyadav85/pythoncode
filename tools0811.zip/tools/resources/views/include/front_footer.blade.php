 <footer>
            <div class="container">
                <div class="footer-content">
                    <a href="#" class="footer-logo">
                        <img src="{{asset('/public/images/textools-white-logo.svg')}}" alt="">
                    </a>
                    <ul class="footer-link">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">How it works</a></li>
                        <li><a href="#">About us</a></li>
                        <li><a href="#">Contact us</a></li>
                        <li><a href="#">Blog</a></li>
                    </ul>
                    <ul class="footer-social-link">
                        <li><a href="#"><img src="{{asset('/public/images/facebook-icon.svg')}}" alt=""></a></li>
                        <li><a href="#"><img src="{{asset('/public/images/pinterest-icon.svg')}}" alt=""></a></li>
                        <li><a href="#"><img src="{{asset('/public/images/instagram-icon.svg')}}" alt=""></a></li>
                        <li><a href="#"><img src="{{asset('/public/images/youtube-icon.svg')}}" alt=""></a></li>
                        <li><a href="#"><img src="{{asset('/public/images/linkedin-icon.svg')}}" alt=""></a></li>
                    </ul>
                </div>
            </div>
            <div class="copyright-wrap">
                <div class="container">
                    <div class="copyright-content">
                        <p>&copy; 2022 Texttool Powered by Texttool</p>
                    </div>
                </div>
            </div>
        </footer>
